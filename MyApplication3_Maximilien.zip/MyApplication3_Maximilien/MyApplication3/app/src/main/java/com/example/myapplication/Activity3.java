package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Activity3 extends Activity_abstract{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity3);

        Button myButton = findViewById(R.id.button1);
        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), Activity.class);
                view.getContext().startActivity(intent);
            }
        });
    }

    public void addFromVariable(View view) {
        Activity_abstract.Nombre ++;
    }

    public void retreveFromVariable(View view) {
        Activity_abstract.Nombre --;
    }

    public void displayNumber(View view) {

    }
}

Activity_abstract.java

        package com.example.myapplication;

        import androidx.appcompat.app.AppCompatActivity;

abstract class Activity_abstract extends AppCompatActivity {
    static int Nombre = 0;
    int Nombre2 = 0;
}